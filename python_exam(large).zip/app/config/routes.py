from system.core.router import routes


routes['default_controller'] = 'Pokes' #redirect to main
routes['/main'] = "Pokes#main"
routes['POST']['/register'] = "Pokes#register"
routes['POST']['/signin'] = "Pokes#signin"
routes['/pokes'] = "Pokes#diplay_pokes"
routes['/pokes/<poked_id>'] = "Pokes#poke"
routes['/logout'] = "Pokes#logout"
routes['/pokes'] = "Pokes#display_pokes"
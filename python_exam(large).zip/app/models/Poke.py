from system.core.model import Model

class Poke(Model):
    def __init__(self):
        super(Poke, self).__init__()

    def get_user_by_email(self, email):
        query = "SELECT * FROM users WHERE email=:email"
        data = {
            'email':email
        }
        rows = self.db.query_db(query,data)
        if len(rows) > 0:
            return rows[0]
        return None

    def create_user(self, info):
        query = "INSERT INTO users (id, name, alias, email, password, pw_salt, dob, created_at, updated_at) VALUES (DEFAULT, :name, :alias, :email, :password, :pw_salt, :dob, NOW(), NOW())"
        data = {
            'name':info['name'],
            'alias':info['alias'],
            'email':info['email'],
            'dob':info['dob'],
            'password':info['password'],
            'pw_salt':info['pw_salt']
        }
        user_id = self.db.query_db(query, data)
        return user_id

    def create_poke(self, info):
        query = "INSERT INTO pokes (id, poked_id, poker_id, created_at, updated_at) VALUES (DEFAULT, :poked_id, :poker_id, NOW(), NOW())"
        return self.db.query_db(query, info)

    def get_all_users_pokes(self):
        query = "SELECT users.id AS id, users.name AS name, users.alias AS alias, users.email AS email, COUNT(pokes.poked_id=users.id) AS poke_count FROM users LEFT JOIN pokes ON pokes.poked_id=users.id GROUP BY users.id"
        return self.db.query_db(query)

    def get_pokes_by_user(self, id):
        return None

    def get_pokes_on_user(self, id):
        query = "SELECT users.alias as poker_alias, users2.alias as poked_alias, users2.id AS poked_id, COUNT(users2.alias) AS pokes FROM users LEFT JOIN pokes ON pokes.poker_id=users.id LEFT JOIN users AS users2 ON users2.id=pokes.poked_id WHERE users2.id=:id GROUP BY users.alias, users2.alias"
        data = {
            "id":id
        }
        return self.db.query_db(query, data)

    def count_pokes_on_user(self, id):
        query = "SELECT COUNT(DISTINCT(pokes.poker_id)) AS dist_pokers FROM pokes WHERE poked_id=:id"
        data = {
            "id":id
        }
        row = self.db.query_db(query, data)
        print row
        return row[0]['dist_pokers']
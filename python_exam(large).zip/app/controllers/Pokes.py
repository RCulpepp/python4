from system.core.controller import *
import re, os, hashlib, binascii

NAME_KEY = re.compile(r'[0-9]')
EMAIL_KEY = re.compile(r'^[a-zA-Z0-9\.\+_-]@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')


class Pokes(Controller):
    def __init__(self, action):
        super(Pokes, self).__init__(action)
     
        self.load_model('Poke')
        self.db = self._app.db
   
    def index(self):
        return redirect("/main")

    def main(self):
        if 'id' in session:
            return redirect('/pokes')
        if 'alias' in session:
            del session['alias']
        if 'email' in session:
            del session['email']
        if 'name' in session:
            del session['name']
        return self.load_view("index.html")

    def register(self):
        is_valid = True
        for k, v in request.form.items():
            if v == '':
                flash("All fields must be filled in.", "regisError")
                is_valid = False
        user = self.models['Poke'].get_user_by_email(request.form['email'])
        if user != None:
            flash("The email address you entered is already in our system.", "regisError")
            is_valid = False
        if (NAME_KEY.search(request.form['name']) != None) or (NAME_KEY.search(request.form['alias']) != None):
            flash("Names and aliases cannot contain numbers", "regisError")
            is_valid = False
        if len(request.form['name']) < 3 or len(request.form['alias']) < 3:
            flash("Names/Aliases must be longer than 2 characters.", "regisError")
            is_valid = False
        if EMAIL_KEY.match(request.form['email']) != None:
            flash("Email address improperly formatted.", "regisError")
            is_valid = False
        if len(request.form['password']) < 9 or request.form['password'] != request.form['confirm-pass']:
            flash("Passwords must match and be at least 8 characters.", "regisError")
            is_valid = False

        if not is_valid:
            session['name'] = request.form['name']
            session['alias'] = request.form['alias']
            session['email'] = request.form['email']
            return redirect('/main')
        
        pw_salt = binascii.hexlify(os.urandom(16))
        password = hashlib.sha256(request.form['password'] + pw_salt).hexdigest()

        info = {
            'name':request.form['name'],
            'alias':request.form['alias'],
            'email':request.form['email'],
            'dob':request.form['dob'],
            'password':password,
            'pw_salt':pw_salt
        }

        user_id = self.models['Poke'].create_user(info)
        session['id'] = user_id
        session['alias'] = info['alias']
        return redirect("/pokes")

    def signin(self):
        user = self.models['Poke'].get_user_by_email(request.form['email'])
        if user == None:
            session['name'] = request.form['name']
            session['alias'] = request.form['alias']
            session['email'] = request.form['email']
            return redirect('/main')

        if hashlib.sha256(request.form['password'] + user['pw_salt']).hexdigest() != user['password']:
            flash("Password does not match our records.", "signError")
            return redirect('/main')
        session['id'] = user['id']
        session['alias'] = user['alias']
        return redirect("/pokes")

    def display_pokes(self):
        count = self.models['Poke'].count_pokes_on_user(session['id'])
        pokers = self.models['Poke'].get_pokes_on_user(session['id'])
        users = self.models['Poke'].get_all_users_pokes()
        return self.load_view('dashboard.html', users=users, pokers=pokers, pokes=count)

    def poke(self, poked_id):
        info = {
            "poked_id":poked_id,
            "poker_id":session['id']
        }
        self.models['Poke'].create_poke(info)

        return redirect('/pokes')

    def logout(self):
        if 'id' in session:
            del session['id']
        if 'alias' in session:
            del session['alias']
        return redirect('/main')

